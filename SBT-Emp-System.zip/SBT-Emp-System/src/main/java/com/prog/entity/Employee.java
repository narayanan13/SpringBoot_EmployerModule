package com.prog.entity;

import java.time.LocalDate;

import javax.persistence.*;

import org.springframework.lang.NonNull;

@Entity
@Table(name = "application")
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(nullable=false,unique=true)
	private int application_id;
	@Column(nullable=false)
	private String intern_title;
	@Column(nullable=false)
	private String qualification;
	@Column(nullable=false)
	private String skills;
	@Column(nullable=false)
	private LocalDate last_date;

	
	

	public Employee(int application_id, String intern_title, String qualification, String skills, LocalDate last_date) {
		super();
//		this.application_id = application_id;
		this.intern_title = intern_title;
		this.qualification = qualification;
		this.skills = skills;
		this.last_date = last_date;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getApplication_id() {
		return application_id;
	}

	public void setApplication_id(int application_id) {
		this.application_id = application_id;
	}

	public String getIntern_title() {
		return intern_title;
	}

	public void setIntern_title(String intern_title) {
		this.intern_title = intern_title;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public LocalDate getLast_date() {
		return last_date;
	}

	public void setLast_date(LocalDate last_date) {
		this.last_date = last_date;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ",application_id=" + application_id + ", intern_title=" + intern_title
				+ ", qualification=" + qualification + ", skills=" + skills + ", last_date=" + last_date + "]";
	}

	
}